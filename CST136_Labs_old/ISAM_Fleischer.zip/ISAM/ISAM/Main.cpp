/*
	@Author: Garrett Fleischer
	@Date:	 10/18/15
*/


#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>

#include "Employee.h"
#include "LinkedList.h"
#include "ISAM.h"


int main()
{
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	ifstream employees("Input.txt");
	if (employees.is_open())
	{
		ISAM<Employee> * isam = new ISAM<Employee>(employees, &Employee::CompareEmployee, &Employee::CompareKey, &Employee::Display);

		cout << Employee::InstanceCount << " Employee instances\n" << endl;

		cout << "Deleting ISAM...\n" << endl;
		delete isam;

		cout << Employee::InstanceCount << " Employee instances\n" << endl;
	}

	return 0;
}