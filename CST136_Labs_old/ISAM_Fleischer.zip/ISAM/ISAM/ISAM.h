/*
@Author: Garrett Fleischer
@Date:	 10/18/15
*/

#ifndef ISAM_H
#define ISAM_H

#include <ios>
using std::ifstream;

#include <vector>
using std::vector;


#include "ISAM_Block.h"

template<class T>
class ISAM
{
public:
	ISAM(ifstream & _file, int(*compare_type)(const T * _t1, const T * _t2), bool(*compare_key)(const T * _t, const string & _key), void(*display)(const T * _item));
	~ISAM();

private:
	static const int MAX_LINE_LEN = 500;
	static const int MAX_ITEMS_PER_BLOCK = 10;
	static const int MAX_BLOCKS = 15;

	vector<Block<T> *> m_blocks; //create a vector of MAX_BLOCKS Block pointers

	int(*CompareType)(const T * _t1, const T * _t2);
	bool(*CompareKey)(const T * _t, const string & _key);
	void(*DisplayItem)(const T * _item);

	void ProcessFile(ifstream & _file);

	void Insert(T * _item);
	
	bool Delete(const string & _key);
	
	int QSearch(const T * _item);

	void Display(int start_index, int end_index);
	
	void Shift(int _index, bool _down);
};


template<class T>
ISAM<T>::ISAM(ifstream & _file, int(*compare_type)(const T * _t1, const T * _t2), bool(*compare_key)(const T * _t, const string & _key), void(*display)(const T * _item))
	: m_blocks(MAX_BLOCKS), CompareType(compare_type), CompareKey(compare_key), DisplayItem(display)
{
	for (int i = 0; i < MAX_BLOCKS; i++)
		m_blocks[i] = new Block<T>(CompareType, CompareKey);

	ProcessFile(_file);
}

template<class T>
ISAM<T>::~ISAM()
{
	for (int i = 0; i < m_blocks.size(); i++)
		delete m_blocks[i];
}

template<class T>
void ISAM<T>::Insert(T * _item)
{
	int index_to_insert = QSearch(_item);

	if (m_blocks[index_to_insert]->Size() < MAX_ITEMS_PER_BLOCK)
		m_blocks[index_to_insert]->Insert(_item);
	else
	{
		if (m_blocks[index_to_insert + 1]->Size() < MAX_ITEMS_PER_BLOCK)
		{
			m_blocks[index_to_insert]->MoveTailNode(*(m_blocks[index_to_insert + 1]));
			m_blocks[index_to_insert]->Insert(_item);
		}
		else
		{
			// shift everything past index_to_insert down one space
			Shift(index_to_insert, true);

			// Attempt to insert _item again
			Insert(_item);
		}
	}
}

template<class T>
bool ISAM<T>::Delete(const string & _key)
{
	bool key_found = false;

	T * item_to_search_for = new T(_key);

	int index = QSearch(item_to_search_for);

	STATUS delete_status = m_blocks[index]->Delete(_key);

	if (delete_status == NORMAL)
	{
		key_found = true;

		if (m_blocks[index]->Size() == 0)
			Shift(index, false);
	}

	delete item_to_search_for;
	
	return key_found;
}

template<class T>
int ISAM<T>::QSearch(const T * _item)
{
	int index = 0;
	bool index_found = false;

	for (int i = 0; i < (MAX_BLOCKS - 1) && !index_found; ++i)
	{
		index = i;

		// if there is room in this block
		bool this_size = (m_blocks[i]->Size() < MAX_ITEMS_PER_BLOCK);
		
		const T * const this_item = m_blocks[i]->FirstItem();
		const T * const this_last = m_blocks[i]->LastItem();
		const T * const next_item = m_blocks[i + 1]->FirstItem();

		// compare _item with:
		int cmp_this = CompareType(_item, this_item);
		int cmp_last = CompareType(_item, this_last);
		int cmp_next = CompareType(_item, next_item);

		// if _item is greater than this_item and this_last exists and _item is less than this_last
		// or there is room in this block and next_item doesn't exist or _item is less than next_item
		if ((cmp_this >= 0 || i == 0) && ((this_last && cmp_last <= 0) || (this_size && (!next_item || cmp_next < 0))))
		{
			index_found = true;
		}
		else if (i > 0)
		{
			// compare _item with:
			int prev_last = CompareType(_item, m_blocks[i - 1]->LastItem());

			// if there is room in this block and _item is greater than prev_last
			// and _item is less than next_first or _item is less than this_first
			if ((prev_last > 0 && (cmp_next <= 0 || cmp_this < 0)))
				index_found = true;
		}
	}

	return index;
}

template<class T>
void ISAM<T>::ProcessFile(ifstream & _file)
{
	char buffer[MAX_LINE_LEN] = { '\0' };
	char command[3] = { '\0' };

	bool program_running = true;

	while (!_file.eof() && program_running)
	{
		_file.read(command, 2); // read in the command, and the space

		for (int i = 0; i < MAX_LINE_LEN; ++i)
			buffer[i] = '\0';

		// read in the command's data
		_file.getline(buffer, MAX_LINE_LEN, '\n');

		// process the command

		// COMMAND 'I'
		if (command[0] == 'I')
		{
			cout << "Inserting: " << buffer << endl;

			Insert(new T(stringstream(buffer)));
		}

		// COMMAND 'R'
		else if (command[0] == 'R')
		{

			stringstream rows(buffer);
			int start = 0;
			int end = 0;
			rows >> start >> end;

			if(start == end)
				cout << endl << "Displaying row: " << start;
			else
				cout << endl << "Displaying rows: " << start << " through " << end;

			Display(start, end);

			cout << endl;
		}

		// COMMAND 'S'
		else if (command[0] == 'S')
		{
			cout << endl << "Searching for: \"" << buffer << "\"" << endl;

			T * item_to_search_for = new T(string(buffer));

			int index = QSearch(item_to_search_for);
			T * const found = m_blocks[index]->Find(string(buffer));
			if (found)
				DisplayItem(found);
			else
				cout << "Unable to find \"" << buffer << "\"..." << endl;

			cout << endl;

			delete item_to_search_for;
		}

		// COMMAND 'D'
		else if (command[0] == 'D')
		{
			cout << endl << "Deleting: \"" << buffer << "\"" << endl;

			if (Delete(string(buffer)))
				cout << "Success!" << endl;
			else
				cout << "Failure!" << endl;

		}

		// COMMAND 'E'
		else if (command[0] == 'E')
		{
			cout << endl << "Program ending...\n" << endl;
			program_running = false;
		}

		// COMMAND ???
		else
		{
			cout << "\nInvalid Command: \"" << command[0] << "\"!\n" << endl;
		}
	}

	

	//cout << readIn << " " << deleted << endl;

	//DisplayAll();
}

template<class T>
void ISAM<T>::Shift(int _index, bool _down)
{
	if (_down)
	{
		// delete the last Block in the list
		delete m_blocks[MAX_BLOCKS - 1];

		// move everything past _index down one space
		for (int i = (MAX_BLOCKS - 1); i > _index; --i)
			m_blocks[i] = m_blocks[i - 1];

		// fill in the gap at (index_to_insert + 1) with a new Block<T>
		m_blocks[_index + 1] = new Block<T>(CompareType, CompareKey);
	}
	else
	{
		// hold a temporary pointer to this block
		delete m_blocks[_index];

		// move everything past _index up one space
		for (int i = _index; i < (MAX_BLOCKS - 1); ++i)
			m_blocks[i] = m_blocks[i + 1];

		// fill in the gap at the end with the copied blank block
		m_blocks[MAX_BLOCKS - 1] = new Block<T>(CompareType, CompareKey);
	}
}


template<class T>
void ISAM<T>::Display(int start_index, int end_index)
{
	for (int i = start_index; i <= end_index; ++i)
	{
		cout << endl << "Row " << i << " contains: " << m_blocks[i]->Size() << " item" << ((m_blocks[i]->Size() != 1) ? "s" : "") << endl;
		m_blocks[i]->DisplayAll(DisplayItem);
		cout << endl;
	}
}

#endif // ISAM_H

