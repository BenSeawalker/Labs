/*
@Author: Garrett Fleischer
@Date:	 10/18/15
*/

#include "Employee.h"


#define npos string::npos

int Employee::InstanceCount = 0;


Employee::Employee()
{
	++InstanceCount;
}

Employee::Employee(const string & _lastName)
	: m_lastName(_lastName)
{
	++InstanceCount;
}

Employee::Employee(const Employee & _emp)
{
	++InstanceCount;
	*this = _emp;
}

Employee::Employee(stringstream & _data)
{
	++InstanceCount;
	_data >> m_workNum >> m_lastName >> m_firstName >> m_bdate >> m_employed;
}


Employee::~Employee()
{
	--InstanceCount;
}

void Employee::Display() const
{
	cout << left << setw(8) << m_workNum << setw(12) << m_lastName
		<< setw(12) << m_firstName << setw(10) << m_bdate << setw(10) << m_employed << endl;
}

void Employee::Display(const Employee * _emp)
{
	if(_emp)
		_emp->Display();
}


int Employee::CompareEmployee(const Employee * _e1, const Employee * _e2)
{
	int diff = 0;

	if (_e1 && _e2)
	{
		int size = ((_e1->m_lastName.length() < _e2->m_lastName.length()) ? _e1->m_lastName.length() : _e2->m_lastName.length());

		diff = stricmp(_e1->m_lastName.substr(0, size).c_str(), _e2->m_lastName.substr(0, size).c_str());
	}

	return diff;
}

bool Employee::CompareKey(const Employee * _emp, const string & _key)
{
	int diff = -1;

	if (_emp)
	{
		int size = ((_emp->m_lastName.length() < _key.length()) ? _emp->m_lastName.length() : _key.length());

		diff = stricmp(_emp->m_lastName.substr(0, size).c_str(), _key.substr(0, size).c_str());
	}

	return (diff == 0);
	//return ((_emp->m_lastName.find(_key, 0) != npos) || (_emp->m_firstName.find(_key, 0) != npos) || (_emp->m_workNum == _key) || (_emp->m_bdate == _key) || _emp->m_employed == _key);
}

